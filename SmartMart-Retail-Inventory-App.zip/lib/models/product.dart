// models/product.dart
class Product {
  String productCode;
  String productName;
  String category;
  double price;
  int quantity;
  String image;
  String status;

  Product({
    required this.productCode,
    required this.productName,
    required this.category,
    required this.price,
    required this.quantity,
    required this.image,
    required this.status,
  });

  // Convert the Product object into one line
  // that can be saved in products.txt (7 fields: code,name,category,price,quantity,status,image)
  String toFileString() {
    return '$productCode,$productName,$category,$price,$quantity,$status,$image';
  }

  // Convert one line from products.txt
  // back into a Product object
  static Product fromFileString(String line) {
    List<String> data = line.split(',');

    // Handle both old format (6 fields) and new format (7 fields)
    String imagePath = data.length > 6 ? data[6] : getImageForProduct(data[0]);

    return Product(
      productCode: data[0],
      productName: data[1],
      category: data[2],
      price: double.parse(data[3]),
      quantity: int.parse(data[4]),
      image: imagePath,
      status: data[5],
    );
  }

  // Choose an image based on the product code
  static String getImageForProduct(String code) {
    switch (code) {
      case 'PRD001':
        return 'assets/images/products/coca_cola.jpg';

      case 'PRD002':
        return 'assets/images/products/bread.jpg';

      case 'PRD003':
        return 'assets/images/products/milk.jpg';

      case 'PRD004':
        return 'assets/images/products/washing_powder.jpg';

      case 'PRD005':
        return 'assets/images/products/keyboard.jpg';

      case 'PRD006':
        return 'assets/images/products/chicken_breast.jpg';

      case 'PRD007':
        return 'assets/images/products/apple.jpg';

      case 'PRD008':
        return 'assets/images/products/bananas.jpg';

      case 'PRD009':
        return 'assets/images/products/coffee_beans.jpg';

      case 'PRD010':
        return 'assets/images/products/desk_lamp.jpg';

      case 'PRD011':
        return 'assets/images/products/dish_soap.jpg';

      case 'PRD012':
        return 'assets/images/products/hand_sanitizer.jpg';

      case 'PRD013':
        return 'assets/images/products/laundry_detergent.jpg';

      case 'PRD014':
        return 'assets/images/products/led_bulb.jpg';

      case 'PRD015':
        return 'assets/images/products/notebook.jpg';

      case 'PRD016':
        return 'assets/images/products/orange_juice.jpg';

      case 'PRD017':
        return 'assets/images/products/potato_chips.jpg';

      case 'PRD018':
        return 'assets/images/products/shampoo.jpg';

      case 'PRD019':
        return 'assets/images/products/wireless_mouse.jpg';

      case 'PRD020':
        return 'assets/images/products/yogurt.jpg';

      default:
        return 'assets/images/products/default.jpg';
    }
  }
}